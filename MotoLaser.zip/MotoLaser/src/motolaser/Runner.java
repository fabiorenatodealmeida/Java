package motolaser;

public class Runner implements Runnable {
  private Game game;
  public Runner(Game game) {
    this.game = game;
  }
  @Override
  public void run() {
    while (!game.collision()) {
      game.go();
      try {
        Thread.sleep(5);
      } catch (Exception e) {
        
      }
    }
    game.boom();
  }
}
