package motolaser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.security.SecureRandom;

public class Game extends JFrame {
  private SecureRandom random = new SecureRandom();
  private int x, y;
  private int width, height;
  private Direction going = Direction.RIGHT;
  private boolean[][] points;
  private Graphics graphics;
  private int score = 0;
  public Game(int width, int height, int x, int y) {
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
    points = new boolean[width][height];
    setRandomPoints();
    setupGUI(width, height);
  }
  private void setRandomPoints() {
    for (int i = 0; i < 50; i++) {
      int x = random.nextInt(width);
      int y = random.nextInt(height);
      for (int dx = x; dx < x + 3 && dx < width; dx++) {
        for (int dy = y; dy < y + 3 && dy < height; dy++) {
          points[dx][dy] = true;
        }
      }
    }
  }
  private void setupGUI(int width, int height) {
    setTitle("Moto Laser");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLayout(new BorderLayout());
    Canvas canvas = new Canvas();
    canvas.setBackground(Color.LIGHT_GRAY);
    canvas.setSize(width, height);
    add(canvas, BorderLayout.CENTER);
    pack();
    setVisible(true);
    graphics = canvas.getGraphics();
    addKeyListener(new KeyListener() {
      @Override
      public void keyTyped(KeyEvent e) {
        
      }

      @Override
      public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
          case KeyEvent.VK_LEFT:
            if (going != Direction.RIGHT) going = Direction.LEFT;
            break;
          case KeyEvent.VK_RIGHT:
            if (going != Direction.LEFT) going = Direction.RIGHT;
            break;
          case KeyEvent.VK_UP:
            if (going != Direction.DOWN) going = Direction.UP;
            break;
          case KeyEvent.VK_DOWN:
            if (going != Direction.UP) going = Direction.DOWN;
            break;
        }
      }

      @Override
      public void keyReleased(KeyEvent e) {
        
      }
    });
  }
  public void start() {
    Thread thread = new Thread(new Runner(this));
    thread.start();
  }
  public boolean collision() {
    return x < 0 || x >= width || y < 0 || y >= height || points[x][y];
  }
  public void boom() {
    graphics.setColor(Color.RED);
    graphics.drawString("Pontos: " + score, 50, 50);
  }
  public void go() {
    points[x][y] = true;
    score++;
    switch (going) {
      case LEFT:
        x--;
        break;
      case RIGHT:
        x++;
        break;
      case UP:
        y--;
        break;
      case DOWN:
        y++;
        break;
    }
    draw();
  }
  private void draw() {
    graphics.setColor(Color.BLUE);
    for (int x = 0; x < width; x++) {
      for (int y = 0; y < height; y++) {
        if (points[x][y]) {
          graphics.drawLine(x, y, x, y);
        }
      }
    }
  }
}
