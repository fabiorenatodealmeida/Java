package motolaser;

public class MotoLaser {
  public static void main(String[] args) {
    Game game = new Game(500, 500, 1, 1);
    game.start();
  }
}
